0) After installing all necessary python related software 

1) you may need to set the appropriate environment:

./set_up_environment.sh

2) you can run unpack the data and put it in the same folder as you run the application by executing in shell:

streamlit run sonify_interact_restricted.py

3) alternatively, you may want to run the general application which offers you the possibility of uploading data files:

streamlit run sonify_interact_restricted.py


credits: Francisco-Shu Kitaura & Emi-Pauline Kitaura

based on: Matt Russo's guide: https://medium.com/@astromattrusso/sonification-101-how-to-convert-data-into-music-with-python-71a6dd67751c
