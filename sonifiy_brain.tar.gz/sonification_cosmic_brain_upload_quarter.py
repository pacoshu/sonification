import streamlit as st
import io
import os
import itertools as it
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import random
from midiutil import MIDIFile
from sklearn.metrics import mean_squared_error
from metrics import calculate_metrics


enable_partiture_creation = True

if enable_partiture_creation:
    from write_partiture import create_partiture, generate_note_names_from_midi
    from music21 import converter, environment
    import subprocess


    def convert_xml_to_pdf(xml_file, pdf_file):
        # Command to convert MusicXML to PDF
        command = ["mscore", xml_file, "-o", pdf_file]
        subprocess.run(command, check=True)


plt.rc('text', usetex=True)

eps = 1e-5
epsv = 1e-5
epsfix = 0

semi_tones_random = False # ATTENTION this might improve the sonification 
quarter_tones_random = False



def get_common_prefix(str1, str2):
    min_len = min(len(str1), len(str2))
    common_prefix = ''
    for i in range(min_len):
        if str1[i] == str2[i]:
            common_prefix += str1[i]
        else:
            break
    return common_prefix


def load_data(filename, norm_data):
    df = pd.read_csv(filename + '.txt', sep='\s+', header=None)
    df.columns = ['x', 'y']

    return df['x'].values, df['y'].values / norm_data

def map_value(value, min_value, max_value, min_result, max_result):
    return min_result + (value - min_value) / (max_value - min_value) * (max_result - min_result)

def ceil_round(value):
    return round(np.ceil(value))

def floor_round(value):
    return round(np.floor(value))

def random_round(value):
    if random.choice([True, False]):
        return round(np.ceil(value))
    else:
        return round(np.floor(value))

def alt_round(value):
    if not hasattr(alt_round, "toggle"):
        alt_round.toggle = True  

    if alt_round.toggle:
        result = round(np.ceil(value))
    else:
        result = round(np.floor(value))

    alt_round.toggle = not alt_round.toggle

    return result
    
def midi_round(value):
    integer_part = int(value)
    decimal_part = value - integer_part
    if decimal_part < 0.5:
        return integer_part
    elif decimal_part == 0.5:
        return random_round(value)
    else:
        return integer_part + 1

def my_round(value, make_diff, are_equal, quarter_tones):
    if quarter_tones:
        # Scale by 2 for quarter-tone precision
        value *= 2
        # Rounding based on conditions
        if make_diff or are_equal:
            if quarter_tones_random:
                rounded_value = random_round(value)
            else:
                rounded_value = midi_round(value)
        else:
            if quarter_tones_random:
                rounded_value = random_round(value)
            else:
                rounded_value = midi_round(value)
        # Scale back to quarter-tone steps without rounding
        return rounded_value / 2
    else:
        # Standard MIDI rounding without quarter tones
        if semi_tones_random:
            return int(random_round(value))
        else:
            return int(midi_round(value))

def my_round_pseudo(value, make_diff, are_equal, quarter_tones):

    my_round_value = 0
  
    if make_diff or are_equal == True:    
        my_round_value = ceil_round(value) # ceil / midi / random     
    else:
        my_round_value = floor_round(value) # floor / midi / random       
                
    if quarter_tones == False:
        my_round_value = midi_round(value) # midi / random 
           
    return my_round_value


def str2midi(note_string):
    """Convert a musical note string with optional quarter tones to a MIDI value."""
    MIDI_A4 = 69  # MIDI note number for A4
    name2delta = {"C": -9, "D": -7, "E": -5, "F": -4, "G": -2, "A": 0, "B": 2}
    accident2delta = {"b": -1, "#": 1, "x": 2}

    # Handle quarter tones
    if "+25" in note_string:
        quarter_tone = 0.5
        note_string = note_string.replace("+25", "")
    else:
        quarter_tone = 0

    # Extract components
    data = note_string.strip()
    note_name = data[0]
    accidentals = ''.join([ch for ch in data[1:] if ch in accident2delta])
    octave = data[len(accidentals) + 1:]
    octave_delta = int(octave) - 4

    # Calculate MIDI note
    midi_value = (MIDI_A4 +
                  name2delta[note_name] +
                  sum(accident2delta[ac] for ac in accidentals) +
                  12 * octave_delta) + quarter_tone

    return midi_value


def sonify_to_midi(filename, filename_ref, output_buffer, plot_diagnostics, fexp, make_diff, quarter_tones, instrument, n_red_notes, norm_data, bpm, duration_beats, duration, vel_min, vel_max):
    
    tick_size = 20
    label_size = 20
    tick_width = 2
    marker_size = 10

    x_ref, ground_truth = load_data(filename_ref, norm_data)
    x, model_data = load_data(filename, norm_data)

    min_length = min(len(ground_truth), len(model_data))
    ground_truth, model_data = ground_truth[:min_length], model_data[:min_length]

    t_data = map_value(x_ref, 0, max(x_ref), 0, duration_beats)
    are_equal = np.array_equal(model_data, ground_truth)

    if make_diff:
        model_data_pos = model_data - ground_truth
    else:
        model_data_pos = model_data + eps

    if plot_diagnostics:
        plt.figure(figsize=(7.5, 6))
        plt.plot(x_ref, model_data_pos, color='k', linestyle='--', linewidth=1)
        plt.scatter(x_ref, model_data_pos, s=3, facecolors='none', edgecolors='k')
        plt.ylabel('$\mathrm{Function}$', fontsize=label_size)
        plt.xlabel('$\mathrm{Angle}$', fontsize=label_size)
        plt.tick_params(axis='both', which='major', labelsize=tick_size, width=tick_width)
        plt.tight_layout()
        plt.savefig('diagnostics_0.pdf', format='pdf')
        st.pyplot(plt)



    if make_diff:
        model_data -= ground_truth
        ground_truth_pos = ground_truth - np.min(ground_truth) + eps
    else:
        model_data += eps 
        ground_truth_pos = ground_truth - np.min(ground_truth) + eps

    min_index = np.argmin(ground_truth_pos)
    ground_truth_pos[min_index]+=epsfix
        
    model_data -= np.min(model_data)                     
    model_data[min_index]+=epsfix

    if plot_diagnostics:
        plt.figure(figsize=(7.5, 6))  
        plt.plot(x_ref, model_data, color='k', linestyle='--', linewidth=1)  
        plt.scatter(x_ref, model_data, s=3, facecolors='none', edgecolors='k')
        #plt.scatter(x_ref, model_data, s=model_data)
        plt.xlabel('$\mathrm{Angle}$', fontsize=label_size)
        plt.ylabel('$\mathrm{Function}$', fontsize=label_size)
        plt.tick_params(axis='both', which='major', labelsize=tick_size, width=tick_width)
        #plt.gca().yaxis.label.set_color('white')
        #plt.gca().tick_params(axis='y', colors='white')
        #plt.gca().tick_params(axis='y', which='both', color='black')
        #plt.ylim(-0.6, 2.)
        plt.tight_layout()
        plt.savefig('diagnostics_1.pdf', format='pdf')        
        st.pyplot(plt)
    
    y_data = map_value(model_data, np.min(model_data), np.max(model_data), np.min(model_data), np.max(model_data))
    tr_y_data = y_data ** fexp * 100  

    if plot_diagnostics:
        plt.figure(figsize=(8, 6))
        plt.scatter(x_ref, tr_y_data, s=tr_y_data, facecolors='none', edgecolors='k')
        plt.xlabel('$\mathrm{Angle}$', fontsize=label_size)
        plt.ylabel('$\mathrm{Function}$', fontsize=label_size)
        plt.tick_params(axis='both', which='major', labelsize=tick_size, width=tick_width)
        plt.tight_layout()
        plt.savefig('diagnostics_2.pdf', format='pdf')
        st.pyplot(plt)

    ymin, ymax = np.min(tr_y_data), np.max(tr_y_data)
    y_data_ref = y_data if make_diff else map_value(ground_truth_pos, np.min(ground_truth_pos), np.max(ground_truth_pos), np.min(ground_truth_pos), np.max(ground_truth_pos))
    tr_y_dataref = y_data_ref ** fexp * 100
    y1min, y1max = np.min(tr_y_dataref), np.max(tr_y_dataref)


    # Define notes with or without quarter tones
    if quarter_tones:

        note_names = [
            'C1', 'C1+25', 'C#1', 'C#1+25', 'D1', 'D1+25', 'D#1', 'D#1+25', 'E1', 'E1+25', 'F1', 'F1+25', 'F#1', 'F#1+25', 'G1', 'G1+25', 'G#1', 'G#1+25', 'A1', 'A1+25', 'A#1', 'A#1+25', 'B1', 'B1+25',
            'C2', 'C2+25', 'C#2', 'C#2+25', 'D2', 'D2+25', 'D#2', 'D#2+25', 'E2', 'E2+25', 'F2', 'F2+25', 'F#2', 'F#2+25', 'G2', 'G2+25', 'G#2', 'G#2+25', 'A2', 'A2+25', 'A#2', 'A#2+25', 'B2', 'B2+25',
            'C3', 'C3+25', 'C#3', 'C#3+25', 'D3', 'D3+25', 'D#3', 'D#3+25', 'E3', 'E3+25', 'F3', 'F3+25', 'F#3', 'F#3+25', 'G3', 'G3+25', 'G#3', 'G#3+25', 'A3', 'A3+25', 'A#3', 'A#3+25', 'B3', 'B3+25',
            'C4', 'C4+25', 'C#4', 'C#4+25', 'D4', 'D4+25', 'D#4', 'D#4+25', 'E4', 'E4+25', 'F4', 'F4+25', 'F#4', 'F#4+25', 'G4', 'G4+25', 'G#4', 'G#4+25', 'A4', 'A4+25', 'A#4', 'A#4+25', 'B4', 'B4+25',
            'C5', 'C5+25', 'C#5', 'C#5+25', 'D5', 'D5+25', 'D#5', 'D#5+25', 'E5', 'E5+25', 'F5', 'F5+25', 'F#5', 'F#5+25', 'G5', 'G5+25', 'G#5', 'G#5+25', 'A5', 'A5+25', 'A#5', 'A#5+25', 'B5', 'B5+25',
            'C6', 'C6+25', 'C#6', 'C#6+25', 'D6', 'D6+25', 'D#6', 'D#6+25', 'E6', 'E6+25', 'F6', 'F6+25', 'F#6', 'F#6+25', 'G6', 'G6+25', 'G#6', 'G#6+25', 'A6', 'A6+25', 'A#6', 'A#6+25', 'B6', 'B6+25',
            'C7', 'C7+25', 'C#7', 'C#7+25', 'D7', 'D7+25', 'D#7', 'D#7+25', 'E7', 'E7+25', 'F7', 'F7+25', 'F#7', 'F#7+25', 'G7', 'G7+25', 'G#7', 'G#7+25', 'A7', 'A7+25', 'A#7', 'A#7+25', 'B7', 'B7+25',
            'C8', 'C8+25', 'C#8', 'C#8+25', 'D8', 'D8+25', 'D#8', 'D#8+25', 'E8', 'E8+25', 'F8', 'F8+25', 'F#8', 'F#8+25', 'G8', 'G8+25', 'G#8', 'G#8+25', 'A8', 'A8+25', 'A#8', 'A#8+25', 'B8', 'B8+25'
        ]

    else:
        
        note_names = [           
            'C1', 'C#1', 'D1', 'D#1', 'E1', 'F1', 'F#1', 'G1', 'G#1', 'A1', 'A#1', 'B1',  
            'C2', 'C#2', 'D2', 'D#2', 'E2', 'F2', 'F#2', 'G2', 'G#2', 'A2', 'A#2', 'B2',  
            'C3', 'C#3', 'D3', 'D#3', 'E3', 'F3', 'F#3', 'G3', 'G#3', 'A3', 'A#3', 'B3',  
            'C4', 'C#4', 'D4', 'D#4', 'E4', 'F4', 'F#4', 'G4', 'G#4', 'A4', 'A#4', 'B4',  
            'C5', 'C#5', 'D5', 'D#5', 'E5', 'F5', 'F#5', 'G5', 'G#5', 'A5', 'A#5', 'B5',  
            'C6', 'C#6', 'D6', 'D#6', 'E6', 'F6', 'F#6', 'G6', 'G#6', 'A6', 'A#6', 'B6',  
            'C7', 'C#7', 'D7', 'D#7', 'E7', 'F7', 'F#7', 'G7', 'G#7', 'A7', 'A#7', 'B7',  
            'C8', 'C#8', 'D8', 'D#8', 'E8', 'F8', 'F#8', 'G8', 'G#8', 'A8', 'A#8', 'B8'       
        ]

    reduced_note_names = note_names[:]
    note_midis = [str2midi(n) for n in reduced_note_names] 
    n_notes = len(note_midis)

    midi_data = []
    midi_pitch_bends = []  # Initialize pitch bend list
    scale_factor = (y1max - y1min) / (ymax - ymin)
    adjusted_y2min, adjusted_y2max = ymin * scale_factor, ymax * scale_factor

    # Main loop to calculate base notes and pitch bends
    flag_ok = True
    while flag_ok:
        flag_ok = False
        for i in range(len(tr_y_data)):
            note_index = my_round(
                map_value(tr_y_data[i], adjusted_y2min, adjusted_y2max, 0, n_notes - 1 - n_red_notes),
                make_diff, are_equal, quarter_tones
            )

            base_note_index = int(np.floor(note_index))
            fractional_part = note_index - base_note_index

            # forces quarter tones
            if quarter_tones:
                fractional_part = round(fractional_part * 4) / 4
            
            # Ensure base_note_index is within range for note_midis list
            if 0 <= base_note_index < len(note_midis):
                base_midi_note = note_midis[base_note_index]
                midi_data.append(base_midi_note)

                # Add pitch bend if there is a fractional part for quarter tones
                pitch_bend_value = int(fractional_part * 8192)  # Scale to pitch bend range [-8192, 8192]
                midi_pitch_bends.append((i, pitch_bend_value))  # Store time index and pitch bend value

            else:
                st.write(f"Warning: note_index {note_index} is out of range. Adjusting n_red_notes and retrying...")
                flag_ok = True
                n_red_notes += 1

    vel_data = [int(map_value(tr_y_data[i], ymin, ymax, vel_min, vel_max)) for i in range(len(tr_y_data))]


    if not make_diff:    
        midi_data_ref = []
        for i in range(len(tr_y_dataref)):
            note_index_ref = my_round(
                map_value(tr_y_dataref[i], adjusted_y2min, adjusted_y2max, 0, n_notes - 1 - n_red_notes),
                make_diff, are_equal, quarter_tones
            )
            
            # Separate integer and fractional parts for pitch bend
            base_note_index_ref = int(np.floor(note_index_ref))
            fractional_part_ref = note_index_ref - base_note_index_ref
            # forces quarter tones
            if quarter_tones:
                fractional_part_ref = round(fractional_part_ref * 4) / 4
 
            if 0 <= base_note_index_ref < len(note_midis):
                base_midi_note_ref = note_midis[base_note_index_ref]
                midi_data_ref.append(base_midi_note_ref)
            else:
                st.write(f"Warning: note_index_ref {note_index_ref} is out of range.")
                
    if plot_diagnostics:
        colorx = 'black'
        colory = 'black'
        
        plt.figure(figsize=(8, 6))
        
        if not make_diff and len(t_data) == len(midi_data_ref):
            plt.scatter(t_data, midi_data_ref, s=tr_y_dataref, facecolors='green', edgecolors='k')
            
        if len(t_data) == len(midi_data):
            plt.scatter(t_data, midi_data, s=tr_y_data, facecolors='none', edgecolors='k')
            
        plt.xlabel('$\mathrm{Time\,[beats]}$', fontsize=label_size, color=colorx)
        plt.ylabel('$\mathrm{Midi\,\,note\,\,numbers}$', fontsize=label_size, color=colory)
        plt.tick_params(axis='x', labelcolor=colorx, color='black', which='major', labelsize=tick_size, width=tick_width)
        plt.tick_params(axis='y', labelcolor=colory, color='black', which='major', labelsize=tick_size, width=tick_width)
        
        plt.tight_layout()
        plt.savefig('diagnostics_3.pdf', format='pdf')
        st.pyplot(plt)

    if plot_diagnostics and len(t_data) == len(midi_data):
        plt.figure(figsize=(8, 6))
        plt.scatter(t_data, midi_data, s=vel_data, facecolors='none', edgecolors='k')
        plt.ylim(20, 130)
        plt.xlabel('$\mathrm{Time\,[beats]}$', fontsize=label_size)
        plt.ylabel('$\mathrm{Midi\,\,note\,\,numbers}$', fontsize=label_size)
        plt.tick_params(axis='both', which='major', labelsize=tick_size, width=tick_width)
        plt.tight_layout()
        plt.savefig('diagnostics_4.pdf', format='pdf')
        st.pyplot(plt)
    
   
    
    # Create MIDI file object and add tempo/program
    my_midi_file = MIDIFile(1)
    my_midi_file.addTempo(track=0, time=0, tempo=bpm)
    my_midi_file.addProgramChange(0, channel=0, time=0, program=instrument)

    # Adding notes and pitch bend messages to MIDI file
    for i, time in enumerate(t_data):
        pitch = int(midi_data[i])  # Base MIDI pitch as an integer
        volume = vel_data[i]  # Volume as integer

        # Add the base note
        my_midi_file.addNote(track=0, channel=0, time=time, pitch=pitch, volume=volume, duration=duration)

    if quarter_tones:
        # Apply pitch bends
        for time_idx, pitch_bend_value in midi_pitch_bends:
            time = t_data[time_idx]
            my_midi_file.addPitchWheelEvent(track=0, channel=0, time=time, pitchWheelValue=pitch_bend_value)

    # Write MIDI data to the provided buffer instead of a file
    my_midi_file.writeFile(output_buffer)
    output_buffer.seek(0)

    if enable_partiture_creation:
        
        # Set MuseScore path (needed for music21 to generate PDFs)
        environment.set('musescoreDirectPNGPath', '/usr/bin/mscore')  # Use actual path returned by `which mscore`
        environment.set('musicxmlPath', '/usr/bin/mscore')
    
        writepart = st.checkbox('Write partiture', value=False)

        if writepart:

            if make_diff:
                common_prefix = get_common_prefix(filename, filename_ref)

                non_common_part1 = filename[len(common_prefix):]
                non_common_part2 = filename_ref[len(common_prefix):]
                
                diff_filename = f"{common_prefix}diff_{non_common_part1}_vs_{non_common_part2}"
                ofilename = diff_filename
            else:
                ofilename = filename
                
            xml_output_file = ofilename + "_partiture.xml"
            pdf_output_file = ofilename + "_partiture.pdf"

            pdf_output_file2 = ofilename + "_midi_notes.pdf"

            title=ofilename
            if quarter_tones:
                title += " with quarter tones"
            
            # Create the partiture and save it as a MusicXML file
            create_partiture(midi_data, midi_pitch_bends, t_data, duration, xml_output_file, title, quarter_tones)

            with open(xml_output_file, "rb") as file:
                st.download_button(label="Download MusicXML Partiture", data=file, file_name=xml_output_file, mime="application/xml")
    
            st.write("The MusicXML partiture has been generated.")


            # Convert to PDF using MuseScore command line
            convert_xml_to_pdf(xml_output_file, pdf_output_file)
    
            with open(pdf_output_file, "rb") as file:
                st.download_button(label="Download Partiture as PDF", data=file, file_name=pdf_output_file, mime="application/pdf")
         
                st.write("The partiture PDF has been generated and is available for download.")


            generate_note_names_pdf_option = st.checkbox("Generate and download note names order PDF")
            
            if generate_note_names_pdf_option:
                note_names_pdf = generate_note_names_from_midi(midi_data, midi_pitch_bends, quarter_tones, pdf_output_file2)
                with open(pdf_output_file2, "rb") as f:
                    st.download_button("Download note names order PDF", f, file_name=pdf_output_file2)
                
    
    return midi_data, np.min(midi_data), np.max(midi_data)


def plot_and_save_pdf(filename, filename_ref, output_buffer, label_gt, label_mod, label_ref, xlabel_ref, ylabel_ref, no_ylabel_b, midi_data, midimin, midimax, no_xaxis, no_yaxis, fexp, make_diff, ylmin, ylmax, yrlmin, yrlmax, ydlmin, ydlmax, norm_data, consv=epsv):
    """Create and save a comparison plot as a PDF."""
    
    x_ref, data_ref = load_data(filename_ref, norm_data)
    x, data = load_data(filename, norm_data)
    
    if make_diff == True:
        ground_truth = data - data_ref
        mingt = np.min(ground_truth)
        ground_truth -= mingt
    else:
        ground_truth = data + consv
    
    ground_truth = ground_truth ** fexp 

    yorgmin = np.min(ground_truth)
    yorgmax = np.max(ground_truth)

    mapped_model = np.array([map_value(midi, midimin, midimax, yorgmin, yorgmax) for midi in midi_data])

    ground_truth = ground_truth ** (1 / fexp)
    mapped_model = mapped_model ** (1 / fexp)

    ratio = (ground_truth + consv) / (mapped_model + consv)

    difference =  mapped_model - ground_truth
 
    if make_diff == True:
        ground_truth += mingt
        mapped_model += mingt

    fig, ax = plt.subplots(3, 1, figsize=(15, 10), sharex=True, gridspec_kw={'height_ratios': [3, 1, 1]})

    tick_size = 40
    label_size = 40
    tick_width = 2
    marker_size = 20

    # First subplot: Original vs Mapped Diameters
    if filename != filename_ref:
        if label_gt == filename:
            ax[0].plot(x_ref, ground_truth + consv, label='$\mathrm{Original\,\,Data}$', marker='o', markerfacecolor='none', markersize=marker_size)
        else:
            ax[0].plot(x_ref, ground_truth + consv, label='$\mathrm{Original\,\,Data}\,\,$'+label_gt, marker='o', markerfacecolor='none', markersize=marker_size)            
    else:
        ax[0].plot(x_ref, ground_truth + consv, marker='o', markerfacecolor='none', markersize=marker_size)

    if label_mod == filename:
        ax[0].plot(x, mapped_model + consv, label='$\mathrm{Sonified\,\,Data}$', marker='x', markersize=marker_size, linestyle='-.')
    else:
        ax[0].plot(x, mapped_model + consv, label='$\mathrm{Sonified\,\,Data}\,\,$'+label_mod, marker='x', markersize=marker_size, linestyle='-.')

    if make_diff == False:
        if filename != filename_ref:
            if label_ref == filename:
                ax[0].plot(x_ref, data_ref + consv, marker='+', markersize=marker_size, label='$\mathrm{Reference\,\, Data}$', linestyle='dotted')
            else:
                ax[0].plot(x_ref, data_ref + consv, marker='+', markersize=marker_size, label='$\mathrm{Reference\,\, Data}\,\,$'+label_ref, linestyle='dotted')
        else:
            if label_ref == filename:
                ax[0].plot(x_ref, data_ref + consv, marker='o', markerfacecolor='none', markersize=marker_size, label='$\mathrm{Reference\,\, Data}$', linestyle='dotted')
            else:
                ax[0].plot(x_ref, data_ref + consv, marker='+', markersize=marker_size, label='$\mathrm{Reference\,\, Data}\,\,$'+label_ref, linestyle='dotted')

    if ylabel_ref == filename:
        ax[0].set_ylabel('$\mathrm{function}$', fontsize=label_size)
    else:
        ax[0].set_ylabel(ylabel_ref, fontsize=label_size)
    
    ax[0].legend(fontsize=label_size)
    ax[0].tick_params(axis='both', which='major', labelsize=tick_size, width=tick_width)

    if no_yaxis == True:
        ax[2].yaxis.label.set_color('white')
        ax[2].tick_params(axis='y', colors='white')
        ax[2].tick_params(axis='y', which='both', color='black')
        ax[1].yaxis.label.set_color('white')
        ax[1].tick_params(axis='y', colors='white')
        ax[1].tick_params(axis='y', which='both', color='black')
        ax[0].yaxis.label.set_color('white')
        ax[0].tick_params(axis='y', colors='white')
        ax[0].tick_params(axis='y', which='both', color='black')
        
        
    # Second subplot: Ratio of Ground Truth to Mapped Data
    ax[1].plot(x, ratio, marker='o', markersize=marker_size, markerfacecolor='none', color='k')
    ax[1].axhline(y=1, color='k', linestyle='--')
    ax[1].set_ylabel('$\\mathrm{Ratio}$', fontsize=label_size)
    ax[1].tick_params(axis='both', which='major', labelsize=tick_size, width=tick_width)

    # Third subplot: Difference between Ground Truth and Ratio
    ax[2].plot(x, difference, marker='o', markersize=marker_size, markerfacecolor='none', color='r', linestyle='--')
    ax[2].axhline(y=0, color='k', linestyle='--')
    ax[2].set_ylabel('$\\mathrm{Difference}$', fontsize=label_size)
    ax[2].tick_params(axis='both', which='major', labelsize=tick_size, width=tick_width)

    if no_ylabel_b == True:
        ax[2].yaxis.label.set_color('white')
        ax[2].tick_params(axis='y', which='both', color='black')
        ax[2].tick_params(axis='both', which='major', labelsize=tick_size, width=tick_width)
        ax[1].yaxis.label.set_color('white')
        ax[1].tick_params(axis='y', which='both', color='black')
        ax[1].plot(x, ratio, marker='o', markersize=marker_size, markerfacecolor='none', color='k')
      
    
    if xlabel_ref == filename:
        ax[2].set_xlabel('$\mathrm{time}$', fontsize=label_size)
    else:
        ax[2].set_xlabel(xlabel_ref, fontsize=label_size)

    if no_xaxis == True:
        ax[2].xaxis.label.set_color('white')
        ax[2].tick_params(axis='x', colors='white')
        ax[2].tick_params(axis='x', which='both', color='black')

    if ylmin != 0 and ylmax != 0:
        ax[0].set_ylim([ylmin, ylmax])
    if yrlmin != 0 and yrlmax != 0:
        ax[1].set_ylim([yrlmin, yrlmax])
    if ydlmin != 0 and ydlmax != 0:
        ax[2].set_ylim([ydlmin, ydlmax])

    plt.tight_layout()

    # Save plot to buffer
    plt.savefig(output_buffer, format='pdf')
    output_buffer.seek(0)
    #plt.show()

def calculate_information_loss(filename, filename_ref, midi_data, midimin, midimax, fexp, make_diff, norm_data):
    """Calculate and print the information loss metrics."""
 
    x_ref, data_ref = load_data(filename_ref, norm_data)
    x, data = load_data(filename, norm_data)
    
    if make_diff == True:
        ground_truth = data - data_ref
        ground_truth -= np.min(ground_truth)
    else:
        ground_truth = data + eps

    min_index = np.argmin(ground_truth)
    ground_truth[min_index]+=epsfix
    
    ground_truth = ground_truth ** fexp

    yorgmin = np.min(ground_truth)
    yorgmax = np.max(ground_truth)

    mapped_model = np.array([map_value(midi, midimin, midimax, yorgmin, yorgmax) for midi in midi_data])

    ground_truth = ground_truth ** (1 / fexp)
    mapped_model = mapped_model ** (1 / fexp)
    
    metrics = calculate_metrics(ground_truth, mapped_model) 

    #for metric, value in metrics.items():
    #    print(f"{metric}: {value:.4f}")

    return metrics
