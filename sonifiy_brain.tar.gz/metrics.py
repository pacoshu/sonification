import numpy as np
from sklearn.metrics import mean_absolute_error, mean_squared_error, r2_score
from scipy.stats import entropy, chisquare
from scipy.spatial.distance import cosine

eps=1e-5

def hellinger(p, q):
    """
    Calculate the Hellinger distance between two probability distributions.

    Parameters:
    p (array-like): The first probability distribution.
    q (array-like): The second probability distribution.

    Returns:
    float: The Hellinger distance.
    
    Description:
    Hellinger Distance:
    Measures the similarity between two probability distributions. 
    Lower values mean more similarity and less information loss.
    """   
    
    return np.sqrt(0.5 * np.sum((np.sqrt(p) - np.sqrt(q)) ** 2))

def my_cross_entropy(p, q, normalize):
    """
    Calculate the Cross-Entropy between two probability distributions.

    Parameters:
    p (array-like): The ground truth probabilities.
    q (array-like): The predicted probabilities.
    eps(float): Small value to avoid log(0)
    normalize (bool):Wether to normalize the cross-entropy by the length of p

    Returns:
    float: The Cross-Entropy value.
    
    Description:
    Cross-Entropy:
    A measure used primarily in classification tasks to quantify the difference 
    between two probability distributions. Lower values indicate that the predicted 
    probability distribution is closer to the true distribution.
    """
    #p = np.array(p)
    #q = np.array(q)
    
    ce=-np.sum(p * np.log(q))  
    if normalize == True:
        ce = ce / len(p)

    return ce 

def calculate_metrics(ground_truth, modeled):
    """
    Calculate various metrics to quantify information loss or error between
    ground truth data and modeled data.

    Parameters:
    ground_truth (array-like): The ground truth data.
    modeled (array-like): The modeled data.

    Returns:
    dict: A dictionary containing various metrics.
    """
    
    # Ensure the inputs are numpy arrays
    ground_truth = np.array(ground_truth)
    modeled = np.array(modeled)

    # Variance of Ground Truth
    variance_gt = np.var(ground_truth)

    
    # Mean Absolute Error (MAE)
    # MAE measures the average absolute difference between the ground truth values 
    # and the modeled values. Lower values indicate less information loss.
    # sum |p-q|
    # |x| = sqrt(x**2)
    mae = mean_absolute_error(ground_truth, modeled)

    nmae = mae / np.sqrt(variance_gt)  * 100 if variance_gt != 0 else np.nan
    
    # Mean Squared Error (MSE)
    # MSE penalizes larger errors more than smaller ones due to the squaring process.
    # Lower values indicate less information loss.
    # sum (p-q)**2
    mse = mean_squared_error(ground_truth, modeled)
    
    # Root Mean Squared Error (RMSE)
    # RMSE is the square root of MSE, providing the error in the same units as the data.
    # Lower values indicate less information loss.
    rmse = np.sqrt(mse)
    
    # R-squared (Coefficient of Determination)
    # R-squared represents the proportion of the variance in the dependent variable 
    # that is predictable from the independent variable. Higher values (close to 1) 
    # indicate less information loss.
    r_squared = r2_score(ground_truth, modeled)
    
    
    # Mean of Ground Truth
    mean_gt = np.mean(ground_truth)
    
    # Normalized Mean Squared Error (NMSE)
    # NMSE is a normalized version of MSE, calculated as MSE divided by the variance of the ground truth. 
    # Lower values indicate that the model's error is small relative to the variability in the data.
    nmse = mse / variance_gt  * 100 if variance_gt != 0 else np.nan
    
    # Relative Mean Squared Error (Relative MSE)
    # Relative MSE is calculated as MSE divided by the square of the mean of the ground truth. 
    # This gives a normalized error relative to the square of the mean value of the ground truth data.
    relative_mse = mse / mean_gt**2  * 100  if mean_gt != 0 else np.nan
    
    # Coefficient of Variation of the RMSE (CVRMSE)
    # CVRMSE expresses the RMSE as a percentage of the mean of the ground truth data. 
    # It is useful for understanding how large the RMSE is relative to the mean value of the data.
    cvrmse = (rmse / np.abs(mean_gt)) * 100 if mean_gt != 0 else np.nan
    
    # Signal-to-Noise Ratio (SNR) for Error
    # SNR is computed to understand how the error compares to the signal (ground truth). 
    # A higher SNR indicates that the model's predictions are close to the actual signal relative to the noise (error).
    snr = variance_gt / mse if mse != 0 else np.nan
    
    # Explained Variance Score
    # Explained Variance is another metric related to R-squared but focuses on how much of the variance 
    # in the ground truth is captured by the model. Higher values (close to 1) indicate better performance.
    explained_variance = 1 - (np.var(ground_truth - modeled) / variance_gt) if variance_gt != 0 else np.nan


    bias = np.mean(modeled-ground_truth)

    nbias = bias / np.sqrt(variance_gt)  * 100 if variance_gt != 0 else np.nan

    # Kullback-Leibler Divergence (KL Divergence)
    # Measures how one probability distribution diverges from a second, expected 
    # probability distribution. Lower values indicate less divergence and therefore 
    # less information loss.

    p = ground_truth
    q = modeled    
    if np.min(p)<0:
        p -= np.min(p)
    if np.min(q)<0:
        q -= np.min(q)
    # Adding a small value to avoid log(0)    
    p += eps
    q += eps

    p/=np.sum(p)
    q/=np.sum(q)

    kl_divergence = entropy(p, q)
    
    # Total Variation Distance (TVD)
    # TVD measures the maximum difference between the probabilities assigned by 
    # two distributions over all events. Lower values indicate less information loss.
    tvd = 0.5 * np.sum(np.abs(p-q))
    
    # Hellinger Distance (from the hellinger function)
    hellinger_dist = hellinger(p,q)
    
    # Cosine Similarity
    # Measures the cosine of the angle between two vectors (ground truth and modeled data). 
    # Values closer to 1 indicate greater similarity, meaning less information loss.
    cosine_sim = 1 - cosine(p,q)

   # Compute Cross-Entropy
    cross_entropy_value = my_cross_entropy(p,q, True)
    
    
    # Compute Chi-Squared
    #chi_squared_value = chi_squared(p, q)

    # Collect results in a dictionary
    metrics = {
        'BIAS': bias,
        'MAE': mae,
        'MSE': mse,
        'RMSE': rmse,
        'NBIAS (%)': nbias,
        'NMAE (%)': nmae,
        'NMSE (%)': nmse,
        'Relative MSE (%)': relative_mse,
        'CVRMSE (%)': cvrmse,
        'SNR': snr,
        'R-squared': r_squared,
        'Explained Variance': explained_variance,
        'Cosine Similarity': cosine_sim,
        'KL Divergence': kl_divergence,
        'Cross-Entropy': cross_entropy_value,
        'Total Variation Distance': tvd,
        'Hellinger Distance': hellinger_dist
     }
    
    return metrics

