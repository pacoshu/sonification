#!/bin/bash

# Exit immediately if a command exits with a non-zero status
set -e

# Step 1: Create a Python virtual environment named 'myenv'
python3 -m venv myenv

# Step 2: Activate the virtual environment
source myenv/bin/activate

# Step 3: Install the required Python packages
pip install streamlit pandas matplotlib MIDIUtil scikit-learn

# Inform the user that setup is complete
echo "Environment setup complete. The virtual environment 'myenv' is now active with the required packages installed."

