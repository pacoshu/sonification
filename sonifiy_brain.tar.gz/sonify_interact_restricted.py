import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import io

from sonification_cosmic_brain_upload_quarter import sonify_to_midi, plot_and_save_pdf, calculate_information_loss, get_common_prefix

def load_data_norm(filename):
    df = pd.read_csv(filename + '.txt', sep='\s+', header=None)
    df.columns = ['x', 'y']

    norm_data = 1.0
    if np.max(np.abs(df['y'].values)) > 10:
        norm_data = np.max(np.abs(df['y'].values))
        st.markdown(f'normalization: {norm_data:.4f}')

    return norm_data
        

st.title("Sonification of the Human Brain")

col1, col2 = st.columns([3, 1])

with col2:
    st.image("LOGO/cosmic_brain.png", width=150)



def display_metric(metric, value):
    if metric == 'BIAS':
        st.markdown(f'{metric}: {value:.4f},  $\,\,\,\,{{BIAS}}(Y, \\hat{{Y}}) = \\frac{{1}}{{n}} \\sum_{{i=1}}^{{n}} (y_i - \\hat{{y}}_i)$')
    if metric == 'MAE':
        st.markdown(f'{metric}: {value:.4f},  $\,\,\,\,{{MAE}}(Y, \\hat{{Y}}) = \\frac{{1}}{{n}} \\sum_{{i=1}}^{{n}} |y_i - \\hat{{y}}_i|$')
    if metric == 'MSE':
        st.markdown(f'{metric}: {value:.4f},  $\,\,\,\,{{MSE}}(Y, \\hat{{Y}}) = \\frac{{1}}{{n}} \\sum_{{i=1}}^{{n}} (y_i - \\hat{{y}}_i)^2$')
    if metric == 'RMSE':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{RMSE}}(Y,\\hat{{Y}}) = \\sqrt{{MSE}}$')
    if metric == 'NBIAS (%)':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{NBIAS}}(Y,\\hat{{Y}}) = \\frac{{BIAS}}{{\\sqrt{{Var(Y)}}}} \\times 100\, [\\%]$')
    if metric == 'NMAE (%)':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{NMAE}}(Y,\\hat{{Y}}) = \\frac{{MAE}}{{Var(Y)}} \\times 100\, [\\%]$')
    if metric == 'NMSE (%)':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{NMSE}}(Y,\\hat{{Y}}) = \\frac{{MSE}}{{Var(Y)}} \\times 100\, [\\%]$')
    if metric == 'Relative MSE (%)':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{ReMSE}}(Y,\\hat{{Y}}) = \\frac{{MSE}}{{\\bar{{y}}^2}} \\times 100\, [\\%]$')
    if metric == 'CVRMSE (%)':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{CVRMSE}}(Y,\\hat{{Y}}) = \\frac{{RMSE}}{{Mean(Y)}} \\times 100\, [\\%]$')
    if metric == 'SNR':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{SNR}}(Y,\\hat{{Y}}) = \\frac{{Var(Y)}}{{MSE}}$')
    if metric == 'R-squared':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{R^2}}(Y,\\hat{{Y}}) = 1 - \\frac{{\\sum_{{i=1}}^{{n}} (y_i - \\hat{{y}}_i)^2}}{{\\sum_{{i=1}}^{{n}} (y_i - \\bar{{y}})^2}}$')
    if metric == 'Explained Variance':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{EVAR}}(Y,\\hat{{Y}}) = 1 - \\frac{{Var(Y - \\hat{{Y}})}}{{Var(Y)}}$')
    if metric == 'Cosine Similarity':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{CS}}(P,Q) = 1 - \\frac{{\\sum_{{i=1}}^{{n}} p_i q_i}}{{\\sqrt{{\\sum_{{i=1}}^{{n}} p_i^2}}\\sqrt{{\\sum_{{i=1}}^{{n}} q_i^2}}}}$')
    if metric == 'KL Divergence':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{D_{{KL}}}}(P,Q) =  \\sum_{{i=1}}^{{n}} p_i \\log \\frac{{ p_i}}{{q_i}}$')
    if metric == 'Cross-Entropy':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{H}}(P,Q) =  \\sum_{{i=1}}^{{n}} p_i \\log {{q_i}}$')
    if metric == 'Total Variation Distance':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{TVD}}(P,Q) =  \\frac{{1}}{{2}}\\sum_{{i=1}}^{{n}} |p_i -q_i| $')
    if metric == 'Hellinger Distance':
        st.markdown(f'{metric}: {value:.4f}, $\,\,\,\,{{D_{{H}}}}(P,Q) =   \\sqrt{{\\frac{{\\sum_{{i=1}}^{{n}}(\\sqrt{{p_i}}-\\sqrt{{q_i}})^2}}{{2}}}}$')

def display_metric_values(metric, value):
    st.write(f'{metric}: {value:.4f}')

def display_metric_details(metric):
    if metric == 'BIAS':
        st.markdown(f'$\,\,\,\,{{BIAS}}(Y, \\hat{{Y}}) = \\frac{{1}}{{n}} \\sum_{{i=1}}^{{n}} (y_i - \\hat{{y}}_i)$')
    if metric == 'MAE':
        st.markdown(f'$\,\,\,\,{{MAE}}(Y, \\hat{{Y}}) = \\frac{{1}}{{n}} \\sum_{{i=1}}^{{n}} |y_i - \\hat{{y}}_i|$')
    if metric == 'MSE':
        st.markdown(f'$\,\,\,\,{{MSE}}(Y, \\hat{{Y}}) = \\frac{{1}}{{n}} \\sum_{{i=1}}^{{n}} (y_i - \\hat{{y}}_i)^2$')
    if metric == 'RMSE':
        st.markdown(f'$\,\,\,\,{{RMSE}}(Y,\\hat{{Y}}) = \\sqrt{{MSE}}$')
    if metric == 'NBIAS (%)':
        st.markdown(f'$\,\,\,\,{{NBIAS}}(Y,\\hat{{Y}}) = \\frac{{BIAS}}{{\\sqrt{{Var(Y)}}}} \\times 100\, [\\%]$')
    if metric == 'NMAE (%)':
        st.markdown(f'$\,\,\,\,{{NMAE}}(Y,\\hat{{Y}}) = \\frac{{MAE}}{{Var(Y)}} \\times 100\, [\\%]$')
    if metric == 'NMSE (%)':
        st.markdown(f'$\,\,\,\,{{NMSE}}(Y,\\hat{{Y}}) = \\frac{{MSE}}{{Var(Y)}} \\times 100\, [\\%]$')
    if metric == 'Relative MSE (%)':
        st.markdown(f'$\,\,\,\,{{ReMSE}}(Y,\\hat{{Y}}) = \\frac{{MSE}}{{\\bar{{y}}^2}} \\times 100\, [\\%]$')
    if metric == 'CVRMSE (%)':
        st.markdown(f'$\,\,\,\,{{CVRMSE}}(Y,\\hat{{Y}}) = \\frac{{RMSE}}{{Mean(Y)}} \\times 100\, [\\%]$')
    if metric == 'SNR':
        st.markdown(f'$\,\,\,\,{{SNR}}(Y,\\hat{{Y}}) = \\frac{{Var(Y)}}{{MSE}}$')
    if metric == 'R-squared':
        st.markdown(f'$\,\,\,\,{{R^2}}(Y,\\hat{{Y}}) = 1 - \\frac{{\\sum_{{i=1}}^{{n}} (y_i - \\hat{{y}}_i)^2}}{{\\sum_{{i=1}}^{{n}} (y_i - \\bar{{y}})^2}}$')
    if metric == 'Explained Variance':
        st.markdown(f'$\,\,\,\,{{EVAR}}(Y,\\hat{{Y}}) = 1 - \\frac{{Var(Y - \\hat{{Y}})}}{{Var(Y)}}$')
    if metric == 'Cosine Similarity':
        st.markdown(f'$\,\,\,\,{{CS}}(P,Q) = 1 - \\frac{{\\sum_{{i=1}}^{{n}} p_i q_i}}{{\\sqrt{{\\sum_{{i=1}}^{{n}} p_i^2}}\\sqrt{{\\sum_{{i=1}}^{{n}} q_i^2}}}}$')
    if metric == 'KL Divergence':
        st.markdown(f'$\,\,\,\,{{D_{{KL}}}}(P,Q) =  \\sum_{{i=1}}^{{n}} p_i \\log \\frac{{ p_i}}{{q_i}}$')
    if metric == 'Cross-Entropy':
        st.markdown(f'$\,\,\,\,{{H}}(P,Q) =  \\sum_{{i=1}}^{{n}} p_i \\log {{q_i}}$')
    if metric == 'Total Variation Distance':
        st.markdown(f'$\,\,\,\,{{TVD}}(P,Q) =  \\frac{{1}}{{2}}\\sum_{{i=1}}^{{n}} |p_i -q_i| $')
    if metric == 'Hellinger Distance':
        st.markdown(f'$\,\,\,\,{{D_{{H}}}}(P,Q) =   \\sqrt{{\\frac{{\\sum_{{i=1}}^{{n}}(\\sqrt{{p_i}}-\\sqrt{{q_i}})^2}}{{2}}}}$')

        
    
# Function to automatically wrap text in $\mathrm{...}$
def format_as_math(text):
    return f'$\\mathrm{{{text}}}$'

sonify_only = st.checkbox('Just sonify a data file?', value=False)

file_options = ['median_bispectrum_4050_019036', 'median_bispectrum_5060_019036', 'median_bispectrum_6070_019036', 'median_bispectrum_7080_019036', 'median_bispectrum_80100_019036']
selected_file = st.selectbox("Choose file to sonify", file_options)

if not sonify_only:
    selected_file_ref = st.selectbox("Choose reference file", file_options)
else:
    selected_file_ref = selected_file  # Default to selected file if sonify_only is true

def load_data_interact(filename):
    """Load data from a predefined file."""
    try:
        df = pd.read_csv(filename + '.txt', sep='\s+', header=None)
        df.columns = ['x', 'y']
        df['x'] = pd.to_numeric(df['x'], errors='coerce')
        df['y'] = pd.to_numeric(df['y'], errors='coerce')

        if df.isna().any().any():
            st.warning("Warning: Some data could not be converted to numeric values. Please check the file format.")
            print(df[df.isna().any(axis=1)])

        return df['x'].values, df['y'].values

    except pd.errors.EmptyDataError:
        st.error("No columns to parse from file. Please check the file format or choose a different file.")
        return None, None
    except Exception as e:
        st.error(f"An unexpected error occurred while reading the file: {e}")
        return None, None


if selected_file:

    filename_raw = selected_file

    if not sonify_only:
        filename_ref_raw = selected_file_ref
    else:
        filename_ref_raw = filename_raw

    if filename_raw == filename_ref_raw: sonify_only = True
        
    common_prefix = get_common_prefix(filename_raw, filename_ref_raw)

    non_common_part1 = filename_raw[len(common_prefix):]
    non_common_part2 = filename_ref_raw[len(common_prefix):]

    diff_filename = f"{common_prefix}diff_{non_common_part1}_vs_{non_common_part2}"

    data_x, data_y = load_data_interact(filename_raw)

    if not sonify_only:
        data_ref_x, data_ref_y = load_data_interact(filename_ref_raw)
    else:
        data_ref_x, data_ref_y = data_x, data_y

    make_diff = False
    flag_continue = False
    if data_x is not None and data_y is not None and data_ref_x is not None and data_ref_y is not None:

        if not sonify_only:
            make_diff = st.radio(
                'Sonify differences to reference? (please choose)',
                options=['Choose...', 'Yes', 'No'],
                index=0
            )

        if make_diff == 'Choose...':
            st.warning("Please select Yes or No to continue.")
        else:
            make_diff = (make_diff == 'Yes')
            flag_continue = True


    if data_x is not None and data_y is not None and data_ref_x is not None and data_ref_y is not None and flag_continue == True:

        quarter_tones = st.checkbox('Notes include quarter tones', value=False)
        
        plot_details = st.checkbox('Show plotting details', value=False)

        xlabel_ref_input = 'Angle/Time' 
        label_ref_input = ''
        no_xaxis = False
        no_yaxis = False
        no_ylabel_b = False
        
        if plot_details == True:
            xlabel_ref_input = st.text_input('Enter x-label (default: Angle/Time)', value='Angle/Time')
            label_ref_input = st.text_input('Enter legend reference', value='')
          
            no_xaxis = st.checkbox('Do not plot x-axis labels (default: false)', value=False)
            no_yaxis = st.checkbox('Do not plot y-axis labels (default: false)', value=False)
            no_ylabel_b = st.checkbox('Do not plot bottom y-labels (default: false)', value=False)


        label_gt_input = ''
        if make_diff:
            ylabel_ref_input = 'Diff-Bispectrum' 
            if plot_details == True:                
                label_gt_input = st.text_input('Enter legend original data', value='')
                ylabel_ref_input = st.text_input('Enter y-label', value='Diff-Bispectrum')

            if not label_gt_input:
                label_gt_input = label_ref_input  
            
            ylmin, ylmax, yrlmin, yrlmax, ydlmin, ydlmax = -0.9, 1.5, 0.8, 1.2, -0.05, 0.05
            
            if plot_details == True:
                yrlmin = st.number_input('Select y-min for the ratio (default: 0.8)', min_value=1e-15, max_value=1e15, value=0.8)
                yrlmax = st.number_input('Select y-max for the ratio (default: 1.2)', min_value=1e-15, max_value=1e15, value=1.2)
                ydlmin = st.number_input('Select y-min for the difference (default: -0.05)', min_value=-1e15, max_value=1e15, value=-0.05)
                ydlmax = st.number_input('Select y-max for the difference (default: 0.05)', min_value=-1e15, max_value=1e15, value=0.05)
                ylmin = st.number_input('Select y-min (default: -0.9)', min_value=-1e15, max_value=1e15, value=-0.9)
                ylmax = st.number_input('Select y-max (default: 1.5)', min_value=-1e15, max_value=1e15, value=1.5)
 
            
        else:
            if plot_details == True:                
                label_gt_input = st.text_input('Enter legend original data', value='')
            if not label_gt_input:
                label_gt_input = label_ref_input

                ylabel_ref_input = 'Bispectrum' 
                if plot_details == True:                
                    ylabel_ref_input = st.text_input('Enter y-label', value='Bispectrum')
                    
                    
                    
#            fexp, ylmin, ylmax, yrlmin, yrlmax, ydlmin, ydlmax, n_red_notes = 1, -3.6, 1.4, 0.6, 1.4, -0.05, 0.05, 0
            ylmin, ylmax, yrlmin, yrlmax, ydlmin, ydlmax = 0, 0, 0, 0, 0, 0

            if plot_details == True:
                yrlmin = st.number_input('Select y-min for the ratio (default: 0.8)', min_value=1e-15, max_value=1e15, value=0.8)
                yrlmax = st.number_input('Select y-max for the ratio (default: 1.2)', min_value=1e-15, max_value=1e15, value=1.2)
                ydlmin = st.number_input('Select y-min for the difference (default: -0.05)', min_value=-1e15, max_value=1e15, value=-0.05)
                ydlmax = st.number_input('Select y-max for the difference (default: 0.05)', min_value=-1e15, max_value=1e15, value=0.05)
                ylmin = st.number_input('Select y-min (default: -0.9)', min_value=-1e15, max_value=1e15, value=-0.9)
                ylmax = st.number_input('Select y-max (default: 1.5)', min_value=-1e15, max_value=1e15, value=1.5)
                
            
        norm_details = st.checkbox('Show transformation details', value=False)

        norm_data = 1.0
        norm_data = load_data_norm(filename_ref_raw)
        norm_data_init = norm_data
        
        fexp = 1

        n_red_notes = 0
        
        if norm_details == True:
            norm_data = st.number_input('Select data normalization (default: 1)', min_value=1e-10, max_value=1e15, value=norm_data_init)
            
            fexp = st.number_input('Select data power-law transformation (default: 1)', min_value=1e-15, max_value=1e15, value=1.0)
            n_red_notes = st.number_input('Reduce number of midi notes range (default: 0)', min_value=0, max_value=50, value=0)

            
        xlabel_ref = format_as_math(xlabel_ref_input)
        label_ref = format_as_math(label_ref_input)
        ylabel_ref = format_as_math(ylabel_ref_input)
        label_gt = format_as_math(label_gt_input)
        label_mod = label_gt


        midi_details = st.checkbox('Show midi details', value=False)

        instrument = 101
        bpm = 60
        duration_beats = 20
        duration = 2
        vel_min = 65
        vel_max = 110
        
        if midi_details == True:
            displaypiano = st.checkbox('Show sonification piano', value=False)

            if displaypiano == True:
                st.image("LOGO/piano.png", use_column_width=True)

            displayinstruments = st.checkbox('Show MIDI instruments list', value=False)

            if displayinstruments == True:
                #st.image("LOGO/Midi_Instrument_List.png", use_column_width=True)

                
                table_content = """
Piano (1-8)                   Chromatic Percussion (9-16)     Organ (17-24)
1: Acoustic Grand Piano       9: Celesta                      17: Drawbar Organ
2: Bright Acoustic Piano      10: Glockenspiel                18: Percussive Organ
3: Electric Grand Piano       11: Music Box                   19: Rock Organ
4: Honky-tonk Piano           12: Vibraphone                  20: Church Organ
5: Electric Piano 1           13: Marimba                     21: Reed Organ
6: Electric Piano 2           14: Xylophone                   22: Accordion
7: Harpsichord                15: Tubular Bells               23: Harmonica
8: Clavinet                   16: Dulcimer                    24: Tango Accordion
                
Guitar (25-32)                Bass (33-40)                    Strings (41-48)
25: Nylon Acoustic Guitar     33: Acoustic Bass               41: Violin
26: Steel Acoustic Guitar     34: Electric Bass (finger)      42: Viola
27: Jazz Electric Guitar      35: Electric Bass (pick)        43: Cello
28: Clean Electric Guitar     36: Fretless Bass               44: Contrabass
29: Muted Electric Guitar     37: Slap Bass 1                 45: Tremolo Strings
30: Overdriven Guitar         38: Slap Bass 2                 46: Pizzicato Strings
31: Distortion Guitar         39: Synth Bass 1                47: Orchestral Harp
32: Guitar Harmonics          40: Synth Bass 2                48: Timpani
                
Ensemble (49-56)              Brass (57-64)                   Reed (65-72)
49: String Ensemble 1         57: Trumpet                     65: Soprano Sax
50: String Ensemble 2         58: Trombone                    66: Alto Sax
51: SynthStrings 1            59: Tuba                        67: Tenor Sax
52: SynthStrings 2            60: Muted Trumpet               68: Baritone Sax
53: Choir Aahs                61: French Horn                 69: Oboe
54: Voice Oohs                62: Brass Section               70: English Horn
55: Synth Voice               63: Synth Brass 1               71: Bassoon
56: Orchestra Hit             64: Synth Brass 2               72: Clarinet
                
Pipe (73-80)                  Synth Lead (81-88)              Synth Pad (89-96)
73: Piccolo                   81: Square Lead                 89: New Age Pad
74: Flute                     82: Saw Lead                    90: Warm Pad
75: Recorder                  83: Calliope Lead               91: Poly Synth Pad
76: Pan Flute                 84: Chiff Lead                  92: Choir Pad
77: Blown Bottle              85: Charang Lead                93: Bowed Pad
78: Shakuhachi                86: Voice Lead                  94: Metallic Pad
79: Whistle                   87: Fifths Lead                 95: Halo Pad
80: Ocarina                   88: Bass + Lead                 96: Sweep Pad
            
Synth Effects (97-104)        Ethnic (105-112)                Percussive (113-120)
97: Rain                      105: Sitar                      113: Tinkle Bell
98: Soundtrack                106: Banjo                      114: Agogo
99: Crystal                   107: Shamisen                   115: Steel Drums
100: Atmosphere               108: Koto                       116: Woodblock
101: Brightness               109: Kalimba                    117: Taiko Drum
102: Goblins                  110: Bagpipe                    118: Melodic Tom
103: Echo Drops               111: Fiddle                     119: Synth Drum
104: Sci-fi                   112: Shanai                     120: Reverse Cymbal
                
Sound Effects (121-128)
121: Guitar Fret Noise
122: Breath Noise
123: Seashore
124: Bird Tweet
125: Telephone Ring
126: Helicopter
127: Applause
128: Gunshot
                """

                #st.title("Instrument List")
                st.text(table_content)


                
                
            instrument = st.number_input('Select instrument (default: 101)', min_value=0, max_value=110, value=101)
            bpm = st.number_input('Select bpm (default: 60)', min_value=1, max_value=1000, value=60)
            duration = st.number_input('Select duration in seconds (default: 2)', min_value=1, max_value=1000, value=2)
            duration_beats = st.number_input('Select duration of beats (default: 20)', min_value=1, max_value=1000, value=20)
            vel_min = st.number_input('Select min velocity (default: 65)', min_value=1, max_value=1000, value=65)
            vel_max = st.number_input('Select max velocity (default: 110)', min_value=1, max_value=1000, value=110)

 
        displayd = st.checkbox('Show sonification steps', value=False)

        plot_diagnostics = False

        if displayd == True:
            plot_diagnostics = True

        # Create in-memory buffers
        midi_buffer = io.BytesIO()
        pdf_buffer = io.BytesIO()
               
        midi_data, midimin, midimax = sonify_to_midi(
            filename_raw, filename_ref_raw, midi_buffer, plot_diagnostics,
            fexp, make_diff, quarter_tones, instrument, n_red_notes, norm_data, bpm, duration_beats, duration, vel_min, vel_max
        )

        plt.figure()
        plot_and_save_pdf(
            filename_raw, filename_ref_raw, pdf_buffer, label_gt, label_mod, label_ref, xlabel_ref,
            ylabel_ref, no_ylabel_b, midi_data, midimin, midimax, no_xaxis, no_yaxis, fexp, make_diff, ylmin, ylmax, yrlmin, yrlmax,
            ydlmin, ydlmax, norm_data
        )

        displayp = st.checkbox('Show data recovery after sonification', value=False)

        if displayp == True:
            st.pyplot(plt)

        

        metrics = calculate_information_loss(
            filename_raw, filename_ref_raw, midi_data, midimin, midimax, fexp, make_diff, norm_data
        )

   
        displaym = st.checkbox('Show metric calculations', value=False)

        if displaym == True:

            for metric, value in metrics.items():
                display_metric_values(metric, value)


        displaym0 = st.checkbox('Show details of the metric calculations', value=False)

        if displaym0 == True:
            
            st.latex(r"""
            \text{Given: } Y = \text{ground truth data set}, \quad \hat{Y} = \text{model data set},
""")

            st.markdown("i) Make the data positive definite:")

            st.latex(r"""
            \text{if } \min(Y) < 0, \text{ then set } Y = Y - \min(Y),
            """)

            st.latex(r"""
            \text{if } \min(\hat{Y}) < 0, \text{ then set } \hat{Y} = \hat{Y} - \min(\hat{Y}),
            """)

            st.markdown("ii) Construct probability distributions:")

            st.latex(r"""
            P = \frac{Y}{\sum Y}, \quad Q = \frac{\hat{Y}}{\sum \hat{Y}}.
            """)

            st.markdown("Mean:")

            st.latex(r"""\bar{y} = \frac{1}{n} \sum_{i=1}^{n} y_i.
            """)

            st.markdown("Variance:")

            st.latex(r"""\text{Var}(Y) = \frac{1}{n-1} \sum_{i=1}^{n} (y_i - \bar{y})^2.
            """)

            st.markdown("Metrics:")

            for metric, value in metrics.items():
                display_metric(metric, value)
        

        displaysketch = st.checkbox('Show sonification diagram', value=False)
        
        if displaysketch == True:
            st.image("LOGO/sonification_sketch.png", use_column_width=True)
                
        filename_out = diff_filename if make_diff else filename_raw
        
        
        midi_buffer.seek(0)
        st.download_button(
            label='Download MIDI file',
            data=midi_buffer,
            file_name=filename_out + '.mid',
            mime='audio/midi'
        )


        pdf_buffer.seek(0)
        st.download_button(
            label='Download PDF file',
            data=pdf_buffer,
            file_name=filename_out + '.pdf',
            mime='application/pdf'
        )

    else:
        if sonify_only == True:
            st.error("Please upload the file to sonify.")
        else:
            st.error("Please upload both the file to sonify and the reference file.")
            
else:
    if sonify_only == True:
        st.error("Please upload the file to sonify.")
    else:
        st.write("Please upload both the file to sonify and the reference file.")


displaycredit = st.checkbox('Show credits', value=False)
        
if displaycredit == True:          
    st.markdown(r"""Sonification software developed by Francisco-Shu Kitaura \& Emi-Pauline Kitaura 2024""")
    st.markdown(r"""Higher order statistical analysis of MRI data  presented in Aurelio Carnero Rosell, Niels Janssen, Antonella Maselli, Ernesto Pereda, Marc Huertas Company and Francisco-Shu Kitaura 2024.""")
    st.markdown(r"""The research conducted in this work was primarily funded by the the Cabildo de Tenerife under IACTEC Technological Training Program, grant TF INNOVA, in support of the Cosmic Brain project (PI: FSK).""") 

